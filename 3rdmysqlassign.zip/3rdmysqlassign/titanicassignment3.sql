use modassign3;
select * from titanic;

/*TASK-1.Write a query to find the name and age of the oldest passenger who survived.*/

select first_name, last_name,age
from titanic
where survived = 1
order by age desc
limit 1;

/*TASK-2.. Create a view to display passenger survival status, class, age, and fare.*/

create view Passenger_Survival as
select survived, pclass,age,fare
from titanic;

/*TASK-3.Create a stored procedure to retrieve passengers based on a given age range.*/

DELIMITER //
create procedure getPassengersByAgeRange(in min_age int, in max_age int) begin
select first_name, last_name, age
from titanic 
where age between min_age and max_age;
end//
DELIMITER ;

/*TASK-4.Write a query to categorize passengers based on the fare they paid: 'Low', 'Medium', or 'High'.*/

select first_name, last_name, fare,
    case
        when fare < 10000 then 'Low'
		when fare between 10000 and 50000 then 'Medium'
        else 'High'
	end as fare_category
from titanic;

/*TASK-5. Show each passenger's fare and the fare of the next passenger.*/

select first_name, last_name, fare,
       lead(fare, 1) over (order by fare) as next_fare
from titanic;

/*TASK-6.. Show the age of each passenger and the age of the previous passenger.*/

select first_name, last_name, age,
	   lag(age, 1) over (order by age) as previous_age
from titanic;

/*TASK-7.Write a query to rank passengers based on their fare, displaying rank for each passenger.*/

select first_name, last_name, fare,
	   RANK() over (order by fare desc) as 'rank'
from titanic;

/*TASK-8.Write a query to rank passengers based on their fare, ensuring no gaps in rank*/

select t1.first_name, t1.last_name, t1.fare,
(select count(distinct t2.fare) from titanic t2 where t2.fare > t1.fare)+ 1 as 'rank'
from titanic t1
order by t1.fare desc
limit 0, 1000;

/*TASK-9.Assign row numbers to passengers based on the order of their fares.*/

select first_name, last_name, fare,
row_number() over (order by fare desc) as 'row_number'
from titanic;

/*TASK-10.Use a CTE to calculate the average fare and find passengers who paid more than the average.*/

with avg_fare_cte as (
     select avg(fare) as avg_fare
     from titanic
)
select first_name, last_name, fare
from titanic
where fare > (select avg_fare from avg_fare_cte);

