use modfinalproject;
select * from walmartsales;

/*Task 1: Identifying the Top Branch by Sales Growth Rate. */

select Branch, month(str_to_date(Date, '%d-%m-%y')) as month, sum(Total) as total_sales,
(sum(total) - lag(sum(Total)) over (partition by Branch order by month(str_to_date(Date, '%d-%m-%y')))) / 
lag(sum(total)) over (partition by branch order by month(str_to_date(Date, '%d-%m-%y'))) * 100 as growth_rate
from walmartsales
group by 
    Branch,
    month(str_to_date(Date, '%d-%m-%y'));


/*Task 2: Finding the Most Profitable Product Line for Each Branch*/

select Branch, 'Product line',
       sum('gross income' - cogs) as profit
from walmartsales
group by Branch, 'Product line'
order by Branch, profit desc;


/*Task 3: Analyzing Customer Segmentation Based on Spending */

SELECT `Customer ID`, 
       SUM(Total) AS total_spending,
       CASE 
           WHEN SUM(Total) >= 5000 THEN 'High'
           WHEN SUM(Total) >= 1000 THEN 'Medium'
           ELSE 'Low'
       END AS spending_category
FROM walmartsales
GROUP BY `Customer ID`
ORDER BY total_spending DESC;


SELECT MIN(SUM(Total)) AS min_spending, MAX(SUM(Total)) AS max_spending
FROM walmartsales
GROUP BY `Customer ID`;


/*Task 4: Detecting Anomalies in Sales Transactions  */

select
    'Invoice ID', 
    Branch, 
    'Product line', 
    Total as total_sales,
    avg(Total) over (partition by 'Product line') AS avg_sales,
    CASE 
        WHEN Total > AVG(Total) over (partition by 'Product line') * 1.5 then 'High'
        WHEN Total < AVG(Total) over (partition by 'Product line') * 0.5 then 'Low'
        else 'Normal'
    END AS anomaly_label
from walmartsales;

/*Task 5: Most Popular Payment Method by City.*/

select City,
       Payment as payment_method,
       count(*) as method_count
from walmartsales
group by City, Payment
order by City, method_count desc;

/*Task 6: Monthly Sales Distribution by Gender */

select month(Date) as months,
Gender,
sum(Total) as total_sales
from walmartsales
group by month(Date), Gender;

/*Task 7: Best Product Line by Customer Type*/

select `Customer type`, `Product line`,
	    sum(Total) as total_sales
from walmartsales
group by `Customer type`, `Product line`
order by `Customer type`, total_sales desc;

/*Task 8: Identifying Repeat Customers */

WITH customer_purchases as (
    select
        `Customer ID`,
        `Date`,
        lead(`Date`) over (partition by `Customer ID` order by `Date`) as next_purchase_date
    from walmartsales
)
select
    `Customer ID`,
    `Date` as first_purchase_date,
    next_purchase_date,
    DATEDIFF(next_purchase_date, `Date`) as days_between_purchases
from customer_purchases
where DATEDIFF(next_purchase_date, `Date`) <= 30
order by `Customer ID`, `Date`;

/*Task 9: Finding Top 5 Customers by Sales Volume*/

select `Customer ID`,
       sum(Total) as total_sales
from walmartsales
group by `Customer ID`
order by total_sales desc
limit 5;

/*Task 10: Analyzing Sales Trends by Day of the Week */

select DAYOFWEEK(STR_TO_DATE(`Date`, '%d-%m-%Y')) AS day_of_week, 
       SUM(`Total`) AS total_sales
from walmartsales
group by DAYOFWEEK(STR_TO_DATE(`Date`, '%d-%m-%Y'))
order by total_sales desc;

SELECT `Date`, 
       STR_TO_DATE(`Date`, '%d-%M-%Y') AS formatted_date
FROM walmartsales
LIMIT 10;

